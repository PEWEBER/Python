#-------------------------------------------------
# This program prompts users to enter an IP address
# that is running the pythonServer.py script. The
# user enters a string and the program returns
# the number of characters, spaces and whether or
# not it contains numbers
#------------------------------------------------


#!/usr/bin/python
#socket_echo_client.py
import socket
import sys


ipAddress = str(input("Enter an IP address: "))
# Create a TCP/IP socket
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect the socket to the port where the server is listening
server_address = (ipAddress, 34001)
print('connecting to {} port {}'.format(*server_address))
sock.connect(server_address)

try:

    # Send data
    message = input("Enter string ").encode()
    print('sending {}'.format(message))
    str(sock.sendall(message))
    # Look for the response
    amount_received = 0
    amount_expected = 55

    if amount_received < amount_expected:
        data = sock.recv(amount_expected)
        amount_received += len(data)
        print('received {!r}'.format(data))

finally:
    print('closing socket')
    sock.close()
