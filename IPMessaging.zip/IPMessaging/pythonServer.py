#-------------------------------------------------
# This program prompts listens for connections
# given by the pythonClient.py script and returns
# the number of characters, spaces and whether
# or not it contains numbers
#------------------------------------------------


#!/usr/bin/python
#socket_echo_server.py
import socket
import sys

def checkInput(input):
    spaces = input.split().count(' ')
    characters = len(input)
    if(input.isalpha()):
        string = f"Characters - {characters}, Spaces - {spaces}, Does not contain numbers"
    else:
        string = f"Characters - {characters}, Spaces - {spaces}, Contains numbers"
    return string



# Create a TCP/IP socket
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM) # Parameters: IP address, TCP socket

# Bind the socket to the port
server_address = ('localhost', 34001) # try localhost too! # '' means willing to recieve from any IP address

sock.bind(server_address)

print('starting up on {} port {}'.format(*server_address))

print('starting up on {} port {}'.format(*sock.getsockname()))


# Listen for incoming connections
sock.listen(1)

while True:
    # Wait for a connection
    print('waiting for a connection')
    connection, client_address = sock.accept()
    try:
        print('connection from', client_address)

        # Receive the data in small chunks and retransmit it
        while True:
            data = connection.recv(16)
            print('received {!r}'.format(data))
            if data:
                print('sending data back to the client')
                connection.sendall(checkInput(data).encode())
            else:
                break

    finally:
        # Clean up the connection
        connection.close()
